import warnings
warnings.filterwarnings("ignore")

import math
import random
import sys
from typing import Any

import limen
import numpy as np
import polars as pl
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    brier_score_loss,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)

from limen.backtest.backtest_snapshot import backtest_snapshot
from limen.data import HistoricalData
from limen.experiment import Manifest
from limen.features import (
    amihud_illiquidity,
    body_to_range,
    close_position,
    cyclical_time_features,
    dollar_volume,
    fractional_diff,
    kline_imbalance,
    range_pct,
    range_per_dollar_volume,
    relative_volatility_seasonality,
    relative_volume_seasonality,
    return_per_dollar_volume,
    trend_coherence,
    trend_strength,
    volatility_of_volatility,
    volatility_term_structure,
    volume_regime,
    vwap,
    wick_imbalance,
)
from limen.features.log_returns import log_returns
from limen.features.returns_lags import returns_lags
from limen.indicators import atr, bbands, cci, mfi, obv, ppo, roc, rolling_volatility, willr, wilder_rsi
from limen.sfd.reference_architecture.base import ReferenceModel


TARGET_COLUMN = "target"
EV_RETURN_COLUMN = "ev_forward_return"
EPSILON = 1e-12

RAW_MARKET_COLUMNS = {
    "open",
    "high",
    "low",
    "close",
    "mean",
    "std",
    "volume",
    "maker_ratio",
    "no_of_trades",
    "open_liquidity",
    "high_liquidity",
    "low_liquidity",
    "close_liquidity",
    "liquidity_sum",
    "maker_volume",
    "maker_liquidity",
}

NON_MODEL_COLUMNS = {"datetime", TARGET_COLUMN, EV_RETURN_COLUMN}

BACKTEST_METRIC_KEYS = [
    "trade_win_rate_pct",
    "trade_expectancy_pct",
    "max_drawdown_pct",
    "total_return_gross_pct",
    "total_return_net_pct",
    "trade_return_mean_win_pct",
    "trade_return_mean_loss_pct",
    "mean_kelly_pct",
    "bars_total",
    "sharpe_per_bar",
    "bars_in_market_pct",
    "trades_count",
    "cost_round_trip_bps",
]


def _as_int(value: Any) -> int:
    return int(round(float(value)))


def _as_float(value: Any) -> float:
    return float(value)


def _as_bool(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "t", "yes", "y"}
    return bool(value)


def _feature_group_enabled(feature_groups: str, group: str) -> bool:
    return feature_groups == "all" or group in feature_groups.split("|")


def consensus_logreg_features(
    data: pl.DataFrame,
    *,
    feature_groups: str = "all",
    frac_diff_d: float = 0.0,
    frac_diff_threshold: float = 0.001,
    return_lag_max: int = 12,
    roc_period: int = 12,
    slow_roc_period: int = 48,
    atr_period: int = 14,
    rsi_period: int = 14,
    ppo_fast: int = 12,
    ppo_slow: int = 26,
    bbands_period: int = 48,
    vol_window: int = 48,
    kline_imbalance_window: int = 24,
    rolling_regime_window: int = 48,
) -> pl.DataFrame:
    feature_groups = str(feature_groups)
    frac_diff_d = _as_float(frac_diff_d)
    frac_diff_threshold = _as_float(frac_diff_threshold)
    return_lag_max = _as_int(return_lag_max)
    roc_period = _as_int(roc_period)
    slow_roc_period = _as_int(slow_roc_period)
    atr_period = _as_int(atr_period)
    rsi_period = _as_int(rsi_period)
    ppo_fast = _as_int(ppo_fast)
    ppo_slow = _as_int(ppo_slow)
    bbands_period = _as_int(bbands_period)
    vol_window = _as_int(vol_window)
    kline_imbalance_window = _as_int(kline_imbalance_window)
    rolling_regime_window = _as_int(rolling_regime_window)

    data = data.sort("datetime")

    data = log_returns(data)
    data = returns_lags(data, max_lag=return_lag_max, returns_col="log_returns")
    data = fractional_diff(data, d=frac_diff_d, cols=["close"], threshold=frac_diff_threshold)

    if _feature_group_enabled(feature_groups, "microstructure"):
        data = range_pct(data)
        data = body_to_range(data)
        data = wick_imbalance(data)
        data = close_position(data)

    if _feature_group_enabled(feature_groups, "momentum"):
        data = roc(data, period=roc_period)
        if slow_roc_period != roc_period:
            data = roc(data, period=slow_roc_period)
        data = ppo(data, fast_period=ppo_fast, slow_period=ppo_slow)
        data = wilder_rsi(data, period=rsi_period)
        data = trend_coherence(
            data,
            short_window=max(2, roc_period),
            medium_window=max(4, slow_roc_period),
            long_window=max(8, slow_roc_period * 2),
        )
        data = trend_strength(data, fast_period=max(2, roc_period), slow_period=max(3, slow_roc_period))

    if _feature_group_enabled(feature_groups, "volatility"):
        data = atr(data, period=atr_period)
        data = bbands(data, period=bbands_period)
        data = cci(data, period=atr_period)
        data = willr(data, period=atr_period)
        data = rolling_volatility(data, column="log_returns", window=vol_window)
        data = volatility_of_volatility(data, volatility_window=max(3, atr_period), window=vol_window)
        data = volatility_term_structure(
            data,
            short_window=max(3, roc_period),
            medium_window=max(6, rolling_regime_window),
            long_window=max(12, rolling_regime_window * 2),
        )

    if _feature_group_enabled(feature_groups, "liquidity"):
        data = vwap(data)
        data = kline_imbalance(data, window=kline_imbalance_window)
        data = dollar_volume(data)
        data = amihud_illiquidity(data)
        data = return_per_dollar_volume(data)
        data = range_per_dollar_volume(data)
        data = obv(data)
        data = mfi(data, period=atr_period)
        data = volume_regime(data, lookback=rolling_regime_window)
        data = relative_volume_seasonality(data)

    if _feature_group_enabled(feature_groups, "seasonality"):
        data = cyclical_time_features(data)
        data = relative_volatility_seasonality(data)

    ppo_col = f"ppo_{ppo_fast}_{ppo_slow}_0"
    atr_col = f"atr_{atr_period}"
    rsi_col = f"wilder_rsi_{rsi_period}"
    bb_width = (pl.col("bbands_upper") - pl.col("bbands_lower")) / (pl.col("bbands_middle").abs() + EPSILON)

    extra_exprs = [
        (pl.col("close").pct_change(1)).alias("close_return_1"),
        (pl.col("high") / (pl.col("low") + EPSILON) - 1.0).alias("bar_range_ratio"),
    ]

    if _feature_group_enabled(feature_groups, "momentum"):
        extra_exprs.extend(
            [
                (pl.col(ppo_col) / 100.0).alias("ppo_fraction"),
                ((pl.col(rsi_col) - 50.0) / 50.0).alias("rsi_centered"),
            ]
        )

    if _feature_group_enabled(feature_groups, "volatility"):
        extra_exprs.extend(
            [
                (pl.col(atr_col) / (pl.col("close").abs() + EPSILON)).alias("atr_fraction"),
                bb_width.alias("bbands_width_fraction"),
                ((pl.col("close") - pl.col("bbands_middle")) / ((pl.col("bbands_upper") - pl.col("bbands_lower")).abs() + EPSILON)).alias("bbands_position"),
            ]
        )

    if _feature_group_enabled(feature_groups, "liquidity"):
        extra_exprs.extend(
            [
                (pl.col("close") / (pl.col("vwap") + EPSILON) - 1.0).alias("close_vs_vwap"),
                (pl.col("maker_volume") / (pl.col("volume") + EPSILON)).alias("maker_volume_ratio"),
                (pl.col("maker_liquidity") / (pl.col("liquidity_sum") + EPSILON)).alias("maker_liquidity_ratio"),
            ]
        )

    return data.with_columns(extra_exprs)


def next_bar_up_target(
    data: pl.DataFrame,
    *,
    target_column: str = TARGET_COLUMN,
    return_column: str = EV_RETURN_COLUMN,
) -> pl.DataFrame:
    # The backtest shifts predictions by one bar and enters on the next bar open.
    # The classifier target should therefore match next-bar open-to-close return.
    forward_return = (pl.col("close").shift(-1) / pl.col("open").shift(-1)) - 1.0
    return data.with_columns(
        [
            forward_return.alias(return_column),
            (forward_return > 0.0).cast(pl.Int8).alias(target_column),
        ]
    )


class NextBarUpTarget:
    def __init__(
        self,
        train_data: pl.DataFrame,
        target_name: str,
        return_column: str = EV_RETURN_COLUMN,
    ) -> None:
        del train_data
        self.target_name = target_name
        self.return_column = return_column

    def transform(self, data: pl.DataFrame) -> pl.DataFrame:
        return next_bar_up_target(
            data,
            target_column=self.target_name,
            return_column=self.return_column,
        )


class CausalRollingRobustScaler:
    def __init__(
        self,
        data: pl.DataFrame,
        *,
        window: int,
        clip: float = 8.0,
        min_samples: int = 50,
        exclude_columns: set[str] | None = None,
    ) -> None:
        self.window = int(window)
        self.clip = float(clip)
        self.min_samples = int(min_samples)
        self.exclude_columns = set(exclude_columns or set()) | {"datetime", EV_RETURN_COLUMN}
        self.columns = [
            col
            for col, dtype in data.schema.items()
            if col not in self.exclude_columns and dtype.is_numeric()
        ]
        self.fallback_center: dict[str, float] = {}
        self.fallback_scale: dict[str, float] = {}
        for col in self.columns:
            stats = data.select(
                [
                    pl.col(col).median().alias("median"),
                    pl.col(col).quantile(0.75).alias("q75"),
                    pl.col(col).quantile(0.25).alias("q25"),
                ]
            ).to_dicts()[0]
            center = stats["median"]
            q75 = stats["q75"]
            q25 = stats["q25"]
            scale = None if q75 is None or q25 is None else abs(float(q75) - float(q25))
            self.fallback_center[col] = 0.0 if center is None or math.isnan(float(center)) else float(center)
            self.fallback_scale[col] = 1.0 if scale is None or scale < EPSILON else scale

    def transform(self, data: pl.DataFrame) -> pl.DataFrame:
        exprs = []
        min_samples = max(1, min(self.min_samples, self.window))
        for col in self.columns:
            if col not in data.columns:
                continue
            center = (
                pl.col(col)
                .rolling_median(window_size=self.window, min_samples=min_samples)
                .shift(1)
                .fill_null(self.fallback_center[col])
            )
            q75 = (
                pl.col(col)
                .rolling_quantile(0.75, window_size=self.window, min_samples=min_samples)
                .shift(1)
                .fill_null(self.fallback_center[col] + self.fallback_scale[col] / 2.0)
            )
            q25 = (
                pl.col(col)
                .rolling_quantile(0.25, window_size=self.window, min_samples=min_samples)
                .shift(1)
                .fill_null(self.fallback_center[col] - self.fallback_scale[col] / 2.0)
            )
            scale = (q75 - q25).abs()
            scaled = (
                pl.when(scale > EPSILON)
                .then((pl.col(col) - center) / scale)
                .otherwise(0.0)
                .clip(-self.clip, self.clip)
                .alias(col)
            )
            exprs.append(scaled)
        return data.with_columns(exprs) if exprs else data


ROLLING_SCALER_WINDOWS = {
    "rolling_robust_1000": 1000,
    "rolling_robust_2000": 2000,
    "rolling_robust_5000": 5000,
}


def _rolling_scaler_factory(
    data: pl.DataFrame,
    *,
    scaler_type: str,
    scaler_clip: float,
    scaler_min_samples: int,
) -> CausalRollingRobustScaler:
    scaler_type = str(scaler_type)
    scaler_clip = _as_float(scaler_clip)
    scaler_min_samples = _as_int(scaler_min_samples)

    if scaler_type not in ROLLING_SCALER_WINDOWS:
        raise ValueError(
            f"Unknown local rolling scaler type {scaler_type!r}. "
            f"Available: {sorted(ROLLING_SCALER_WINDOWS)}"
        )
    return CausalRollingRobustScaler(
        data,
        window=ROLLING_SCALER_WINDOWS[scaler_type],
        clip=scaler_clip,
        min_samples=scaler_min_samples,
    )


def _apply_local_fitted_scaler(
    data: pl.DataFrame,
    *,
    fitted_transform: CausalRollingRobustScaler,
) -> pl.DataFrame:
    return fitted_transform.transform(data)


def set_local_rolling_scaler_from_params(
    manifest: Manifest,
    param_name: str = "scaler_type",
) -> Manifest:
    manifest.scaler = (
        [
            (
                "_local_rolling_scaler",
                _rolling_scaler_factory,
                {
                    "scaler_type": param_name,
                    "scaler_clip": "scaler_clip",
                    "scaler_min_samples": "scaler_min_samples",
                },
            )
        ],
        _apply_local_fitted_scaler,
        {"fitted_transform": "_local_rolling_scaler"},
    )
    return manifest


def _to_numpy_series(values: Any) -> np.ndarray:
    if isinstance(values, pl.Series):
        return values.to_numpy()
    return np.asarray(values)


def _model_columns(frame: pl.DataFrame, *, include_raw_market_features: bool) -> list[str]:
    columns = []
    for col, dtype in frame.schema.items():
        if col in NON_MODEL_COLUMNS:
            continue
        if not include_raw_market_features and col in RAW_MARKET_COLUMNS:
            continue
        if dtype.is_numeric():
            columns.append(col)
    return columns


def _frame_to_numpy(frame: pl.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        raise ValueError("No model columns are available after feature selection.")
    return (
        frame.select(columns)
        .with_columns(pl.all().cast(pl.Float64))
        .fill_nan(None)
        .fill_null(0.0)
        .to_numpy()
    )


def _safe_auc(y_true: np.ndarray, probs: np.ndarray) -> float:
    return float(roc_auc_score(y_true, probs)) if len(np.unique(y_true)) > 1 else float("nan")


def _safe_log_loss(y_true: np.ndarray, probs: np.ndarray) -> float:
    try:
        return float(log_loss(y_true, probs, labels=[0, 1]))
    except ValueError:
        return float("nan")


def _expected_calibration_error(y_true: np.ndarray, probs: np.ndarray, *, bins: int = 10) -> float:
    if len(y_true) == 0:
        return float("nan")
    edges = np.linspace(0.0, 1.0, bins + 1)
    ece = 0.0
    for left, right in zip(edges[:-1], edges[1:]):
        if right == 1.0:
            mask = (probs >= left) & (probs <= right)
        else:
            mask = (probs >= left) & (probs < right)
        if not mask.any():
            continue
        ece += float(mask.mean()) * abs(float(y_true[mask].mean()) - float(probs[mask].mean()))
    return float(ece)


def _winsorized_mean(values: np.ndarray, *, q: float) -> float:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return 0.0
    q = min(max(float(q), 0.0), 0.49)
    lo, hi = np.quantile(values, [q, 1.0 - q])
    return float(np.clip(values, lo, hi).mean())


def _scalar_payoff_estimates(
    y: np.ndarray,
    returns: np.ndarray,
    *,
    q: float,
) -> tuple[float, float]:
    y = np.asarray(y, dtype=int)
    returns = np.asarray(returns, dtype=float)
    up = returns[y == 1]
    down = -returns[y == 0]
    up_mean = max(_winsorized_mean(up, q=q), EPSILON)
    down_mean = max(_winsorized_mean(down, q=q), EPSILON)
    return up_mean, down_mean


def _bucketed_expected_returns(
    calibration_probs: np.ndarray,
    calibration_returns: np.ndarray,
    test_probs: np.ndarray,
    *,
    bins: int,
    q: float,
) -> np.ndarray:
    calibration_probs = np.asarray(calibration_probs, dtype=float)
    calibration_returns = np.asarray(calibration_returns, dtype=float)
    test_probs = np.asarray(test_probs, dtype=float)
    bins = max(2, int(bins))
    edges = np.quantile(calibration_probs[np.isfinite(calibration_probs)], np.linspace(0.0, 1.0, bins + 1))
    edges = np.unique(edges)
    if edges.size < 3:
        return np.full_like(test_probs, _winsorized_mean(calibration_returns, q=q), dtype=float)

    fallback = _winsorized_mean(calibration_returns, q=q)
    bucket_values = []
    for left, right in zip(edges[:-1], edges[1:]):
        if right == edges[-1]:
            mask = (calibration_probs >= left) & (calibration_probs <= right)
        else:
            mask = (calibration_probs >= left) & (calibration_probs < right)
        bucket_values.append(_winsorized_mean(calibration_returns[mask], q=q) if mask.any() else fallback)

    bucket_index = np.searchsorted(edges[1:-1], test_probs, side="right")
    return np.asarray([bucket_values[i] for i in bucket_index], dtype=float)


def _apply_calibration(
    *,
    method: str,
    val_probs: np.ndarray,
    val_y: np.ndarray,
    train_probs: np.ndarray,
    test_probs: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, str]:
    method = method.lower()
    if method == "none" or len(np.unique(val_y)) < 2:
        return train_probs, val_probs, test_probs, "none"

    if method == "platt":
        x_val = np.log(np.clip(val_probs, EPSILON, 1.0 - EPSILON) / np.clip(1.0 - val_probs, EPSILON, 1.0)).reshape(-1, 1)
        calibrator = LogisticRegression(solver="lbfgs", C=1.0, max_iter=200)
        calibrator.fit(x_val, val_y)

        def transform(probs: np.ndarray) -> np.ndarray:
            logits = np.log(np.clip(probs, EPSILON, 1.0 - EPSILON) / np.clip(1.0 - probs, EPSILON, 1.0)).reshape(-1, 1)
            return calibrator.predict_proba(logits)[:, 1]

        return transform(train_probs), transform(val_probs), transform(test_probs), "platt"

    if method == "isotonic":
        calibrator = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
        calibrator.fit(val_probs, val_y)
        return (
            calibrator.transform(train_probs),
            calibrator.transform(val_probs),
            calibrator.transform(test_probs),
            "isotonic",
        )

    raise ValueError("calibration_method must be one of: none, platt, isotonic")


def _cost_fraction(*, fee_bps: float, slip_bps: float) -> float:
    return max(0.0, (float(fee_bps) + float(slip_bps)) / 10_000.0)


def _stateful_predictions(
    probs: np.ndarray,
    *,
    entry_threshold: float,
    exit_threshold: float,
) -> np.ndarray:
    preds = np.zeros(len(probs), dtype=int)
    state = 0
    for i, prob in enumerate(probs):
        if state == 0:
            if prob >= entry_threshold:
                state = 1
        else:
            if prob < exit_threshold:
                state = 0
        preds[i] = state
    return preds


def _rolling_probability_floor(
    probs: np.ndarray,
    *,
    window: int,
    quantile: float,
    min_samples: int,
    fallback: float,
) -> np.ndarray:
    probs = np.asarray(probs, dtype=float)
    floors = np.full(len(probs), float(fallback), dtype=float)
    window = max(1, int(window))
    min_samples = max(1, int(min_samples))
    quantile = min(max(float(quantile), 0.0), 1.0)
    for i in range(len(probs)):
        left = max(0, i - window)
        history = probs[left:i]
        history = history[np.isfinite(history)]
        if history.size >= min_samples:
            floors[i] = float(np.quantile(history, quantile))
    return floors


def _stateful_predictions_with_thresholds(
    probs: np.ndarray,
    *,
    entry_thresholds: np.ndarray,
    hysteresis_prob: float,
) -> np.ndarray:
    preds = np.zeros(len(probs), dtype=int)
    state = 0
    hysteresis_prob = float(hysteresis_prob)
    for i, prob in enumerate(probs):
        entry_threshold = float(entry_thresholds[i])
        exit_threshold = max(0.0, entry_threshold - hysteresis_prob)
        if state == 0:
            if prob >= entry_threshold:
                state = 1
        else:
            if prob < exit_threshold:
                state = 0
        preds[i] = state
    return preds


def _adaptive_entry_thresholds(
    probs: np.ndarray,
    *,
    base_threshold: float,
    adaptive_threshold_mode: str,
    adaptive_quantile: float,
    adaptive_window: int,
    adaptive_min_samples: int,
) -> np.ndarray:
    probs = np.asarray(probs, dtype=float)
    base = np.full(len(probs), float(base_threshold), dtype=float)
    if adaptive_threshold_mode.lower() == "none":
        return base
    if adaptive_threshold_mode.lower() != "rolling_quantile":
        raise ValueError("adaptive_threshold_mode must be one of: none, rolling_quantile")
    floor = _rolling_probability_floor(
        probs,
        window=adaptive_window,
        quantile=adaptive_quantile,
        min_samples=adaptive_min_samples,
        fallback=base_threshold,
    )
    return np.maximum(base, floor)


def _decision_threshold(
    *,
    mode: str,
    val_probs: np.ndarray,
    prob_threshold: float,
    signal_quantile: float,
    min_prob_floor: float,
) -> float:
    mode = mode.lower()
    if mode == "probability":
        return float(prob_threshold)
    if mode == "val_quantile":
        finite = val_probs[np.isfinite(val_probs)]
        if finite.size == 0:
            return float(prob_threshold)
        threshold = float(np.quantile(finite, float(signal_quantile)))
        return max(float(min_prob_floor), threshold)
    if mode == "val_return":
        return float(prob_threshold)
    raise ValueError("threshold_mode must be one of: probability, val_quantile, val_return")


def _count_transitions(preds: np.ndarray) -> tuple[int, int]:
    if len(preds) == 0:
        return 0, 0
    previous = np.r_[0, preds[:-1]]
    entries = int(((preds == 1) & (previous == 0)).sum())
    exits = int(((preds == 0) & (previous == 1)).sum())
    if preds[-1] == 1:
        exits += 1
    return entries, exits


def _choose_return_threshold(
    *,
    val_probs: np.ndarray,
    val_returns: np.ndarray,
    threshold_grid_min: float,
    threshold_grid_max: float,
    threshold_grid_steps: int,
    hysteresis_prob: float,
    min_signal_rate: float,
    max_signal_rate: float,
    one_way_cost: float,
    fallback_threshold: float,
    adaptive_threshold_mode: str,
    adaptive_quantile: float,
    adaptive_window: int,
    adaptive_min_samples: int,
) -> tuple[float, float, float, float]:
    val_probs = np.asarray(val_probs, dtype=float)
    val_returns = np.asarray(val_returns, dtype=float)
    finite = np.isfinite(val_probs) & np.isfinite(val_returns)
    if not finite.any():
        return float(fallback_threshold), float("nan"), 0.0, 0.0

    probs = val_probs[finite]
    returns = val_returns[finite]
    fixed_grid = np.linspace(float(threshold_grid_min), float(threshold_grid_max), int(threshold_grid_steps))
    quantile_grid = np.quantile(probs, np.linspace(0.50, 0.90, 9))
    thresholds = sorted(set(float(x) for x in np.r_[fixed_grid, quantile_grid] if np.isfinite(x)))
    if not thresholds:
        return float(fallback_threshold), float("nan"), 0.0, 0.0

    best_threshold = float(fallback_threshold)
    best_score = -float("inf")
    best_signal_rate = 0.0
    best_mean_return = float("nan")

    for threshold in thresholds:
        entry_thresholds = _adaptive_entry_thresholds(
            probs,
            base_threshold=threshold,
            adaptive_threshold_mode=adaptive_threshold_mode,
            adaptive_quantile=adaptive_quantile,
            adaptive_window=adaptive_window,
            adaptive_min_samples=adaptive_min_samples,
        )
        preds = _stateful_predictions_with_thresholds(
            probs,
            entry_thresholds=entry_thresholds,
            hysteresis_prob=hysteresis_prob,
        )
        signal_rate = float(preds.mean()) if len(preds) else 0.0
        if signal_rate < float(min_signal_rate) or signal_rate > float(max_signal_rate):
            continue
        entries, exits = _count_transitions(preds)
        gross = float(np.sum(np.where(preds == 1, returns, 0.0)))
        net = gross - (float(one_way_cost) * float(entries + exits))
        mean_return = float(np.mean(returns[preds == 1])) if preds.any() else float("nan")
        if net > best_score:
            best_threshold = threshold
            best_score = net
            best_signal_rate = signal_rate
            best_mean_return = mean_return

    if best_score == -float("inf"):
        return float(fallback_threshold), float("nan"), 0.0, 0.0
    return best_threshold, best_score, best_signal_rate, best_mean_return


def _kelly_fraction(
    probs: np.ndarray,
    *,
    up_mean: float,
    down_mean: float,
    fraction: float,
    cap: float,
) -> np.ndarray:
    payout_ratio = up_mean / max(down_mean, EPSILON)
    raw = probs - ((1.0 - probs) / max(payout_ratio, EPSILON))
    return np.clip(raw * fraction, 0.0, cap)


def _empty_backtest_metrics() -> dict[str, float]:
    return {f"backtest_{key}": float("nan") for key in BACKTEST_METRIC_KEYS}


def _backtest_metrics(
    data: dict,
    preds: np.ndarray,
    *,
    fee_bps: float,
    slip_bps: float,
    execution_lag_bars: int,
) -> dict[str, float]:
    price_data = data.get("price_data_for_backtest")
    if price_data is None or len(preds) == 0:
        return _empty_backtest_metrics()
    price_data = price_data.with_columns(
        [
            pl.Series("predictions", preds.astype(int)),
            (pl.col("close") - pl.col("open")).alias("price_change"),
        ]
    )
    snapshot = backtest_snapshot(
        price_data.to_pandas(),
        pred_col="predictions",
        fee_bps=fee_bps,
        slip_bps=slip_bps,
        execution_lag_bars=execution_lag_bars,
    ).iloc[0].to_dict()
    return {f"backtest_{key}": float(value) for key, value in snapshot.items()}


def threshold_logreg_binary(
    data: dict,
    *,
    solver: str = "lbfgs",
    penalty: str = "l2",
    C: float = 1.0,
    class_weight: float = 0.75,
    max_iter: int = 200,
    tol: float = 0.001,
    fit_intercept: bool = True,
    calibration_method: str = "none",
    threshold_mode: str = "probability",
    prob_threshold: float = 0.51,
    signal_quantile: float = 0.60,
    min_prob_floor: float = 0.50,
    threshold_grid_min: float = 0.49,
    threshold_grid_max: float = 0.56,
    threshold_grid_steps: int = 29,
    min_signal_rate: float = 0.03,
    max_signal_rate: float = 0.80,
    hysteresis_prob: float = 0.02,
    adaptive_threshold_mode: str = "none",
    adaptive_quantile: float = 0.65,
    adaptive_window: int = 250,
    adaptive_min_samples: int = 50,
    payoff_quantile_clip: float = 0.03,
    fee_bps: float = 4.0,
    slip_bps: float = 2.0,
    execution_lag_bars: int = 1,
    kelly_fraction: float = 0.25,
    kelly_cap: float = 0.10,
    include_raw_market_features: bool = False,
    random_state: int = 42,
) -> dict[str, Any]:
    solver = str(solver)
    penalty = str(penalty)
    C = _as_float(C)
    class_weight = _as_float(class_weight)
    max_iter = _as_int(max_iter)
    tol = _as_float(tol)
    fit_intercept = _as_bool(fit_intercept)
    calibration_method = str(calibration_method)
    threshold_mode = str(threshold_mode)
    prob_threshold = _as_float(prob_threshold)
    signal_quantile = _as_float(signal_quantile)
    min_prob_floor = _as_float(min_prob_floor)
    threshold_grid_min = _as_float(threshold_grid_min)
    threshold_grid_max = _as_float(threshold_grid_max)
    threshold_grid_steps = _as_int(threshold_grid_steps)
    min_signal_rate = _as_float(min_signal_rate)
    max_signal_rate = _as_float(max_signal_rate)
    hysteresis_prob = _as_float(hysteresis_prob)
    adaptive_threshold_mode = str(adaptive_threshold_mode)
    adaptive_quantile = _as_float(adaptive_quantile)
    adaptive_window = _as_int(adaptive_window)
    adaptive_min_samples = _as_int(adaptive_min_samples)
    payoff_quantile_clip = _as_float(payoff_quantile_clip)
    fee_bps = _as_float(fee_bps)
    slip_bps = _as_float(slip_bps)
    execution_lag_bars = _as_int(execution_lag_bars)
    kelly_fraction = _as_float(kelly_fraction)
    kelly_cap = _as_float(kelly_cap)
    include_raw_market_features = _as_bool(include_raw_market_features)
    random_state = _as_int(random_state)

    model_cols = _model_columns(data["x_train"], include_raw_market_features=include_raw_market_features)

    x_train = _frame_to_numpy(data["x_train"], model_cols)
    x_val = _frame_to_numpy(data["x_val"], model_cols)
    x_test = _frame_to_numpy(data["x_test"], model_cols)
    y_train = _to_numpy_series(data["y_train"]).astype(int)
    y_val = _to_numpy_series(data["y_val"]).astype(int)
    y_test = _to_numpy_series(data["y_test"]).astype(int)

    val_returns = _to_numpy_series(data["x_val"][EV_RETURN_COLUMN]).astype(float)
    test_returns = _to_numpy_series(data["x_test"][EV_RETURN_COLUMN]).astype(float)

    if len(np.unique(y_train)) < 2:
        probs_train = np.full(len(y_train), float(y_train.mean()) if len(y_train) else 0.5)
        probs_val = np.full(len(y_val), probs_train[0] if len(probs_train) else 0.5)
        probs_test = np.full(len(y_test), probs_train[0] if len(probs_train) else 0.5)
    else:
        class_weight_arg = {0: float(class_weight), 1: 1.0}
        model = LogisticRegression(
            solver=solver,
            penalty=penalty,
            C=C,
            class_weight=class_weight_arg,
            max_iter=max_iter,
            tol=tol,
            fit_intercept=fit_intercept,
            random_state=random_state,
        )
        model.fit(x_train, y_train)
        probs_train = model.predict_proba(x_train)[:, 1]
        probs_val = model.predict_proba(x_val)[:, 1]
        probs_test = model.predict_proba(x_test)[:, 1]

    probs_train, probs_val, probs_test, calibration_used = _apply_calibration(
        method=calibration_method,
        val_probs=probs_val,
        val_y=y_val,
        train_probs=probs_train,
        test_probs=probs_test,
    )

    up_mean, down_mean = _scalar_payoff_estimates(y_val, val_returns, q=payoff_quantile_clip)
    entry_cost = _cost_fraction(fee_bps=fee_bps, slip_bps=slip_bps)
    gross_expected_test = (probs_test * up_mean) - ((1.0 - probs_test) * down_mean)
    entry_expected_test = gross_expected_test - entry_cost

    break_even_prob = (down_mean + entry_cost) / max(up_mean + down_mean, EPSILON)
    threshold_mode_lower = threshold_mode.lower()
    val_threshold_score = float("nan")
    val_threshold_signal_rate = float("nan")
    val_threshold_mean_return_bps = float("nan")
    if threshold_mode_lower == "val_return":
        entry_threshold, val_threshold_score, val_threshold_signal_rate, val_threshold_mean_return = _choose_return_threshold(
            val_probs=probs_val,
            val_returns=val_returns,
            threshold_grid_min=threshold_grid_min,
            threshold_grid_max=threshold_grid_max,
            threshold_grid_steps=threshold_grid_steps,
            hysteresis_prob=hysteresis_prob,
            min_signal_rate=min_signal_rate,
            max_signal_rate=max_signal_rate,
            one_way_cost=entry_cost,
            fallback_threshold=prob_threshold,
            adaptive_threshold_mode=adaptive_threshold_mode,
            adaptive_quantile=adaptive_quantile,
            adaptive_window=adaptive_window,
            adaptive_min_samples=adaptive_min_samples,
        )
        val_threshold_mean_return_bps = val_threshold_mean_return * 10_000.0 if np.isfinite(val_threshold_mean_return) else float("nan")
        val_threshold_score = val_threshold_score * 10_000.0 if np.isfinite(val_threshold_score) else float("nan")
        val_threshold_signal_rate *= 100.0
    else:
        entry_threshold = _decision_threshold(
            mode=threshold_mode_lower,
            val_probs=probs_val,
            prob_threshold=prob_threshold,
            signal_quantile=signal_quantile,
            min_prob_floor=min_prob_floor,
        )
    exit_threshold = max(0.0, entry_threshold - float(hysteresis_prob))
    entry_thresholds = _adaptive_entry_thresholds(
        probs_test,
        base_threshold=entry_threshold,
        adaptive_threshold_mode=adaptive_threshold_mode,
        adaptive_quantile=adaptive_quantile,
        adaptive_window=adaptive_window,
        adaptive_min_samples=adaptive_min_samples,
    )
    preds = _stateful_predictions_with_thresholds(
        probs_test,
        entry_thresholds=entry_thresholds,
        hysteresis_prob=hysteresis_prob,
    )

    kelly = _kelly_fraction(
        probs_test,
        up_mean=up_mean,
        down_mean=down_mean,
        fraction=kelly_fraction,
        cap=kelly_cap,
    )
    kelly = np.where(preds == 1, kelly, 0.0)

    results: dict[str, Any] = {
        "accuracy": float(accuracy_score(y_test, preds)) if len(y_test) else float("nan"),
        "precision": float(precision_score(y_test, preds, zero_division=0)) if len(y_test) else float("nan"),
        "recall": float(recall_score(y_test, preds, zero_division=0)) if len(y_test) else float("nan"),
        "auc": _safe_auc(y_test, probs_test),
        "log_loss": _safe_log_loss(y_test, probs_test),
        "brier": float(brier_score_loss(y_test, probs_test)) if len(y_test) else float("nan"),
        "ece": _expected_calibration_error(y_test, probs_test),
        "signal_rate_pct": float(preds.mean() * 100.0) if len(preds) else 0.0,
        "mean_pred_prob": float(np.mean(probs_test)) if len(probs_test) else float("nan"),
        "mean_signal_prob": float(np.mean(probs_test[preds == 1])) if preds.any() else float("nan"),
        "mean_realized_forward_return_bps": float(np.mean(test_returns) * 10_000.0) if len(test_returns) else float("nan"),
        "mean_expected_return_bps": float(np.mean(gross_expected_test) * 10_000.0) if len(gross_expected_test) else float("nan"),
        "mean_entry_expected_return_bps": float(np.mean(entry_expected_test) * 10_000.0) if len(entry_expected_test) else float("nan"),
        "mean_signal_expected_return_bps": float(np.mean(gross_expected_test[preds == 1]) * 10_000.0) if preds.any() else float("nan"),
        "mean_signal_entry_expected_return_bps": float(np.mean(entry_expected_test[preds == 1]) * 10_000.0) if preds.any() else float("nan"),
        "realized_signal_forward_return_bps": float(np.mean(test_returns[preds == 1]) * 10_000.0) if preds.any() else float("nan"),
        "payoff_up_bps": float(up_mean * 10_000.0),
        "payoff_down_bps": float(down_mean * 10_000.0),
        "entry_cost_bps": float(entry_cost * 10_000.0),
        "break_even_prob": float(break_even_prob),
        "entry_threshold": float(entry_threshold),
        "exit_threshold": float(exit_threshold),
        "mean_live_entry_threshold": float(np.mean(entry_thresholds)) if len(entry_thresholds) else float("nan"),
        "p95_live_entry_threshold": float(np.quantile(entry_thresholds, 0.95)) if len(entry_thresholds) else float("nan"),
        "max_pred_prob": float(np.max(probs_test)) if len(probs_test) else float("nan"),
        "p95_pred_prob": float(np.quantile(probs_test, 0.95)) if len(probs_test) else float("nan"),
        "p05_pred_prob": float(np.quantile(probs_test, 0.05)) if len(probs_test) else float("nan"),
        "threshold_pass_rate_pct": float((probs_test >= entry_threshold).mean() * 100.0) if len(probs_test) else 0.0,
        "threshold_mode_used": threshold_mode,
        "val_threshold_score_bps": float(val_threshold_score),
        "val_threshold_signal_rate_pct": float(val_threshold_signal_rate),
        "val_threshold_mean_return_bps": float(val_threshold_mean_return_bps),
        "calibration_used": calibration_used,
        "n_features": len(model_cols),
        "kelly_mean_pct": float(kelly.mean() * 100.0) if len(kelly) else 0.0,
        "kelly_signal_mean_pct": float(kelly[preds == 1].mean() * 100.0) if preds.any() else float("nan"),
        "kelly_max_pct": float(kelly.max() * 100.0) if len(kelly) else 0.0,
        "_preds": preds,
    }
    results.update(
        _backtest_metrics(
            data,
            preds,
            fee_bps=fee_bps,
            slip_bps=slip_bps,
            execution_lag_bars=execution_lag_bars,
        )
    )
    return results


class BtcLogRegEVReferenceModel(ReferenceModel):
    deterministic = True

    def train(self, data: dict, **params: Any) -> "BtcLogRegEVReferenceModel":
        solver = str(params.get("solver", "lbfgs"))
        penalty = str(params.get("penalty", "l2"))
        C = _as_float(params.get("C", 1.0))
        class_weight = _as_float(params.get("class_weight", 0.75))
        max_iter = _as_int(params.get("max_iter", 200))
        tol = _as_float(params.get("tol", 0.001))
        fit_intercept = _as_bool(params.get("fit_intercept", True))
        self.random_state = _as_int(params.get("random_state", 42))
        self.include_raw_market_features = _as_bool(params.get("include_raw_market_features", False))
        self.calibration_method = str(params.get("calibration_method", "none"))
        self.threshold_mode = str(params.get("threshold_mode", "probability"))
        self.prob_threshold = _as_float(params.get("prob_threshold", 0.51))
        self.signal_quantile = _as_float(params.get("signal_quantile", 0.60))
        self.min_prob_floor = _as_float(params.get("min_prob_floor", 0.50))
        self.threshold_grid_min = _as_float(params.get("threshold_grid_min", 0.49))
        self.threshold_grid_max = _as_float(params.get("threshold_grid_max", 0.56))
        self.threshold_grid_steps = _as_int(params.get("threshold_grid_steps", 29))
        self.min_signal_rate = _as_float(params.get("min_signal_rate", 0.03))
        self.max_signal_rate = _as_float(params.get("max_signal_rate", 0.80))
        self.hysteresis_prob = _as_float(params.get("hysteresis_prob", 0.02))
        self.adaptive_threshold_mode = str(params.get("adaptive_threshold_mode", "none"))
        self.adaptive_quantile = _as_float(params.get("adaptive_quantile", 0.65))
        self.adaptive_window = _as_int(params.get("adaptive_window", 250))
        self.adaptive_min_samples = _as_int(params.get("adaptive_min_samples", 50))
        self.payoff_quantile_clip = _as_float(params.get("payoff_quantile_clip", 0.03))
        self.fee_bps = _as_float(params.get("fee_bps", 4.0))
        self.slip_bps = _as_float(params.get("slip_bps", 2.0))
        self.execution_lag_bars = _as_int(params.get("execution_lag_bars", 1))
        self.kelly_fraction = _as_float(params.get("kelly_fraction", 0.25))
        self.kelly_cap = _as_float(params.get("kelly_cap", 0.10))
        self.params = dict(params)

        self.model_cols = _model_columns(data["x_train"], include_raw_market_features=self.include_raw_market_features)
        self.training_feature_columns = list(data["x_train"].columns)
        self.model_col_indices = [
            i for i, col in enumerate(self.training_feature_columns)
            if col in self.model_cols
        ]
        x_train = _frame_to_numpy(data["x_train"], self.model_cols)
        y_train = _to_numpy_series(data["y_train"]).astype(int)

        if len(np.unique(y_train)) < 2:
            self.model = None
            self.constant_prob = float(y_train.mean()) if len(y_train) else 0.5
            train_probs = np.full(len(y_train), self.constant_prob)
        else:
            self.constant_prob = None
            self.model = LogisticRegression(
                solver=solver,
                penalty=penalty,
                C=C,
                class_weight={0: class_weight, 1: 1.0},
                max_iter=max_iter,
                tol=tol,
                fit_intercept=fit_intercept,
                random_state=self.random_state,
            )
            self.model.fit(x_train, y_train)
            train_probs = self.model.predict_proba(x_train)[:, 1]

        source_x = data["x_val"] if "x_val" in data and len(data["x_val"]) > 0 else data["x_train"]
        source_y = data["y_val"] if "y_val" in data and len(data["y_val"]) > 0 else data["y_train"]
        source_returns = _to_numpy_series(source_x[EV_RETURN_COLUMN]).astype(float)
        source_y_np = _to_numpy_series(source_y).astype(int)
        source_probs_raw = self._raw_probs(source_x)

        self.calibrator = None
        source_probs = self._fit_calibrator(source_probs_raw, source_y_np)
        self.up_mean, self.down_mean = _scalar_payoff_estimates(
            source_y_np,
            source_returns,
            q=self.payoff_quantile_clip,
        )

        entry_cost = _cost_fraction(fee_bps=self.fee_bps, slip_bps=self.slip_bps)
        if self.threshold_mode.lower() == "val_return":
            self.entry_threshold, _, _, _ = _choose_return_threshold(
                val_probs=source_probs,
                val_returns=source_returns,
                threshold_grid_min=self.threshold_grid_min,
                threshold_grid_max=self.threshold_grid_max,
                threshold_grid_steps=self.threshold_grid_steps,
                hysteresis_prob=self.hysteresis_prob,
                min_signal_rate=self.min_signal_rate,
                max_signal_rate=self.max_signal_rate,
                one_way_cost=entry_cost,
                fallback_threshold=self.prob_threshold,
                adaptive_threshold_mode=self.adaptive_threshold_mode,
                adaptive_quantile=self.adaptive_quantile,
                adaptive_window=self.adaptive_window,
                adaptive_min_samples=self.adaptive_min_samples,
            )
        else:
            self.entry_threshold = _decision_threshold(
                mode=self.threshold_mode,
                val_probs=source_probs,
                prob_threshold=self.prob_threshold,
                signal_quantile=self.signal_quantile,
                min_prob_floor=self.min_prob_floor,
            )

        return self

    def _raw_probs(self, frame: Any) -> np.ndarray:
        if self.model is None:
            return np.full(len(frame), self.constant_prob)
        if isinstance(frame, pl.DataFrame):
            x = _frame_to_numpy(frame, self.model_cols)
        else:
            x = np.asarray(frame, dtype=float)
            if x.ndim == 1:
                x = x.reshape(1, -1)
            if x.shape[1] == len(self.training_feature_columns):
                x = x[:, self.model_col_indices]
        return self.model.predict_proba(x)[:, 1]

    def _fit_calibrator(self, probs: np.ndarray, y: np.ndarray) -> np.ndarray:
        method = self.calibration_method.lower()
        if method == "none" or len(np.unique(y)) < 2:
            self.calibrator = None
            return probs
        if method == "platt":
            logits = np.log(np.clip(probs, EPSILON, 1.0 - EPSILON) / np.clip(1.0 - probs, EPSILON, 1.0)).reshape(-1, 1)
            self.calibrator = LogisticRegression(solver="lbfgs", C=1.0, max_iter=200)
            self.calibrator.fit(logits, y)
            return self._calibrate(probs)
        if method == "isotonic":
            self.calibrator = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
            self.calibrator.fit(probs, y)
            return self._calibrate(probs)
        raise ValueError("calibration_method must be one of: none, platt, isotonic")

    def _calibrate(self, probs: np.ndarray) -> np.ndarray:
        if self.calibrator is None:
            return probs
        if self.calibration_method.lower() == "platt":
            logits = np.log(np.clip(probs, EPSILON, 1.0 - EPSILON) / np.clip(1.0 - probs, EPSILON, 1.0)).reshape(-1, 1)
            return self.calibrator.predict_proba(logits)[:, 1]
        return self.calibrator.transform(probs)

    def predict(self, data: dict) -> dict:
        frame = data["x_test"] if "x_test" in data and len(data["x_test"]) > 0 else data["x_train"]
        probs = self._calibrate(self._raw_probs(frame))
        entry_thresholds = _adaptive_entry_thresholds(
            probs,
            base_threshold=self.entry_threshold,
            adaptive_threshold_mode=self.adaptive_threshold_mode,
            adaptive_quantile=self.adaptive_quantile,
            adaptive_window=self.adaptive_window,
            adaptive_min_samples=self.adaptive_min_samples,
        )
        preds = _stateful_predictions_with_thresholds(
            probs,
            entry_thresholds=entry_thresholds,
            hysteresis_prob=self.hysteresis_prob,
        )
        kelly = _kelly_fraction(
            probs,
            up_mean=self.up_mean,
            down_mean=self.down_mean,
            fraction=self.kelly_fraction,
            cap=self.kelly_cap,
        )
        return {"_preds": preds, "_probs": probs, "_kelly": np.where(preds == 1, kelly, 0.0)}

    def evaluate(self, data: dict, inline_metrics: bool = True) -> dict:
        if "x_val" in data and "x_test" in data and "y_test" in data and len(data["x_test"]) > 0:
            return threshold_logreg_binary(data, **self.params)
        return self.predict(data)


class BtcLogRegEVSFD:
    @staticmethod
    def params() -> dict[str, list[Any]]:
        return {
            "feature_groups": ["all"],
            "frac_diff_d": [0.0, 0.4],
            "frac_diff_threshold": [0.001],
            "shift": [-1],
            "return_lag_max": [3, 6],
            "roc_period": [4],
            "slow_roc_period": [24],
            "atr_period": [7],
            "rsi_period": [28],
            "ppo_fast": [16],
            "ppo_slow": [21],
            "bbands_period": [96],
            "vol_window": [96],
            "kline_imbalance_window": [12, 24],
            "rolling_regime_window": [48],
            "scaler_type": ["rolling_robust_1000"],
            "scaler_clip": [8.0],
            "scaler_min_samples": [50],
            "solver": ["lbfgs"],
            "penalty": ["l2"],
            "C": [10.0],
            "class_weight": [0.45],
            "max_iter": [200],
            "tol": [0.001],
            "fit_intercept": [True],
            "calibration_method": ["none"],
            "threshold_mode": ["val_return"],
            "prob_threshold": [0.51],
            "signal_quantile": [0.60],
            "min_prob_floor": [0.50],
            "threshold_grid_min": [0.50],
            "threshold_grid_max": [0.54],
            "threshold_grid_steps": [21, 29],
            "min_signal_rate": [0.03, 0.05],
            "max_signal_rate": [0.50],
            "hysteresis_prob": [0.01],
            "adaptive_threshold_mode": ["rolling_quantile"],
            "adaptive_quantile": [0.55, 0.60, 0.65],
            "adaptive_window": [250],
            "adaptive_min_samples": [30, 50],
            "payoff_quantile_clip": [0.03],
            "fee_bps": [1.0],
            "slip_bps": [0.5],
            "execution_lag_bars": [1],
            "kelly_fraction": [0.25],
            "kelly_cap": [0.10],
            "include_raw_market_features": [True],
            "random_state": [42],
            "runner_nonce": list(range(100000)),
        }

    @staticmethod
    def manifest() -> Manifest:
        manifest = (
            Manifest()
            .set_data_source(
                method=HistoricalData.get_spot_klines,
                params={"kline_size": 14400, "start_date_limit": "2024-01-01"},
            )
            .set_test_data_source(
                method=HistoricalData.get_spot_klines,
                params={"kline_size": 14400, "start_date_limit": "2024-01-01"},
            )
            .set_split_config(8, 1, 2)
            .add_feature(
                consensus_logreg_features,
                feature_groups="feature_groups",
                frac_diff_d="frac_diff_d",
                frac_diff_threshold="frac_diff_threshold",
                return_lag_max="return_lag_max",
                roc_period="roc_period",
                slow_roc_period="slow_roc_period",
                atr_period="atr_period",
                rsi_period="rsi_period",
                ppo_fast="ppo_fast",
                ppo_slow="ppo_slow",
                bbands_period="bbands_period",
                vol_window="vol_window",
                kline_imbalance_window="kline_imbalance_window",
                rolling_regime_window="rolling_regime_window",
            )
            .with_target_label(TARGET_COLUMN, NextBarUpTarget)
        )
        return set_local_rolling_scaler_from_params(manifest, "scaler_type").with_reference_architecture(threshold_logreg_binary)


def params() -> dict[str, list[Any]]:
    return BtcLogRegEVSFD.params()


def manifest() -> Manifest:
    return BtcLogRegEVSFD.manifest()


if __name__ == "__main__":
    from datetime import datetime

    random.seed(42)
    np.random.seed(42)

    historical = limen.HistoricalData()
    data = historical.get_spot_klines(kline_size=14400, start_date_limit="2024-01-01")

    data = data.filter(pl.col("ts") < datetime(2026, 4, 13))

    uel = limen.UniversalExperimentLoop(data=data, sfd=sys.modules[__name__])
    uel.run(
        experiment_name="btc-logreg-adaptive-4h-final",
        n_permutations=100,
        prep_each_round=True,
        random_search=True,
    )
